#!/bin/sh

python3 decision_tree.py
